eSports Management System - eSMS Team </br> 
Dejan Stosic </br>
Bojan Adamovic  </br>
Milutin Stankovic </br>
Mario Zalac