<body>
    <h3>Hello {{ $username }},</h3>
    <p>
        You have recently asked for password recovery at ESMS system. 
    </p>
    <p>
        To reset your password, please navigate to the following link:
    </p>
    {{ $link }} 
    <hr>
    
    ESMS Team
</body>